
import { useState, useCallback } from 'react';
import toast from 'react-hot-toast';
import { ImageInfo, HistogramData, ImageData } from '../types';

const BINS = 32;

export const useImageAnalysis = () => {
  const [imageData, setImageData] = useState<ImageData | null>(null);
  const [imageInfo, setImageInfo] = useState<ImageInfo | null>(null);
  const [histogramData, setHistogramData] = useState<HistogramData | null>(null);

  const analyzeImage = useCallback((file: File, base64: string, mimeType: string) => {
    const img = new Image();
    img.onload = () => {
      // Get dimensions and aspect ratio
      const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
      const commonDivisor = gcd(img.width, img.height);
      setImageInfo({
        width: img.width,
        height: img.height,
        aspectRatio: `${img.width / commonDivisor}:${img.height / commonDivisor}`,
      });

      // Analyze histogram
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      
      ctx.drawImage(img, 0, 0);
      const pixelData = ctx.getImageData(0, 0, img.width, img.height).data;
      
      const r = new Array(BINS).fill(0);
      const g = new Array(BINS).fill(0);
      const b = new Array(BINS).fill(0);

      for (let i = 0; i < pixelData.length; i += 4) {
        r[Math.floor(pixelData[i] / (256 / BINS))]++;
        g[Math.floor(pixelData[i + 1] / (256 / BINS))]++;
        b[Math.floor(pixelData[i + 2] / (256 / BINS))]++;
      }
      setHistogramData({ r, g, b });
      setImageData({ file, base64, mimeType });
    };
    img.onerror = () => {
      toast.error('تعذر تحميل ملف الصورة للتحليل.');
    };
    img.src = base64;
  }, []);

  const setImageFile = useCallback((file: File | null) => {
    if (!file) {
      setImageData(null);
      setImageInfo(null);
      setHistogramData(null);
      return;
    }
    
    const validTypes = ['image/png', 'image/jpeg', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      toast.error('صيغة الملف غير مدعومة. الرجاء استخدام PNG, JPG, أو WEBP.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      if (base64) {
        analyzeImage(file, base64, file.type);
      }
    };
    reader.onerror = () => {
        toast.error('حدث خطأ أثناء قراءة الملف.');
    };
    reader.readAsDataURL(file);
  }, [analyzeImage]);
  
  const clearImage = useCallback(() => {
    setImageFile(null);
  }, [setImageFile]);

  return { imageData, imageInfo, histogramData, setImageFile, clearImage };
};

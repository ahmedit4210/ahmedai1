
import React, { useState, useCallback, useEffect } from 'react';
import toast from 'react-hot-toast';
import { Sidebar } from './components/Sidebar';
import { ImagePanel } from './components/ImagePanel';
import { Header } from './components/Header';
import { UploadPlaceholder } from './components/UploadPlaceholder';
import { LoadingSpinner } from './components/icons';
import { useImageAnalysis } from './hooks/useImageAnalysis';
import { generateImageFromAngle } from './services/geminiService';
import { CameraControls, ImageInfo } from './types';
import { DEFAULT_CONTROLS, PROMPT_TEMPLATES } from './constants';

const App: React.FC = () => {
  const [controls, setControls] = useState<CameraControls>(DEFAULT_CONTROLS);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('generic');
  
  const { 
    imageData, 
    imageInfo, 
    histogramData,
    setImageFile, 
    clearImage
  } = useImageAnalysis();
  
  const [generatedImage, setGeneratedImage] = useState<{ url: string; info: ImageInfo } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  const handleGenerate = useCallback(async () => {
    if (!imageData) {
      toast.error('الرجاء رفع صورة أولاً.');
      return;
    }

    setIsLoading(true);
    setGeneratedImage(null);
    toast('جاري توليد الصورة...', { icon: '🤖' });

    const template = PROMPT_TEMPLATES.find(t => t.id === selectedTemplate)?.template || PROMPT_TEMPLATES[0].template;

    const prompt = template
      .replace('{zoom}', controls.zoom.toString())
      .replace('{yaw}', controls.yaw.toString())
      .replace('{pitch}', controls.pitch.toString())
      .replace('{roll}', controls.roll.toString())
      .replace('{panx}', controls.panX.toString())
      .replace('{pany}', controls.panY.toString());

    try {
      const result = await generateImageFromAngle(imageData, prompt);
      if (result) {
        setGeneratedImage({
          url: result,
          info: {
            // Placeholder info for generated image, can be improved with analysis
            width: imageInfo?.width || 0,
            height: imageInfo?.height || 0,
            aspectRatio: imageInfo?.aspectRatio || '1:1'
          }
        });
        toast.success('تم توليد الصورة بنجاح!');
      } else {
        throw new Error('لم يتم إرجاع أي صورة من النموذج.');
      }
    } catch (error) {
      console.error("Error generating image:", error);
      toast.error('حدث خطأ أثناء توليد الصورة.');
    } finally {
      setIsLoading(false);
    }
  }, [imageData, controls, selectedTemplate, imageInfo]);

  const resetControls = useCallback(() => {
    setControls(DEFAULT_CONTROLS);
    toast('تمت إعادة تعيين الإعدادات.');
  }, []);
  
  const handleImageUpload = (file: File) => {
    setImageFile(file);
    setGeneratedImage(null);
  };
  
  const handleClearImage = () => {
    clearImage();
    setGeneratedImage(null);
  }

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement && ['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
          return;
      }

      setControls(prev => {
        let newControls = { ...prev };
        switch (e.key) {
          case 'ArrowUp':
            e.preventDefault();
            newControls.panY = Math.min(1, parseFloat((prev.panY + 0.05).toFixed(2)));
            break;
          case 'ArrowDown':
            e.preventDefault();
            newControls.panY = Math.max(-1, parseFloat((prev.panY - 0.05).toFixed(2)));
            break;
          case 'ArrowLeft':
            e.preventDefault();
            newControls.panX = Math.max(-1, parseFloat((prev.panX - 0.05).toFixed(2)));
            break;
          case 'ArrowRight':
            e.preventDefault();
            newControls.panX = Math.min(1, parseFloat((prev.panX + 0.05).toFixed(2)));
            break;
          case '+':
          case '=':
            e.preventDefault();
            newControls.zoom = Math.min(4, parseFloat((prev.zoom + 0.1).toFixed(2)));
            break;
          case '-':
            e.preventDefault();
            newControls.zoom = Math.max(0.25, parseFloat((prev.zoom - 0.1).toFixed(2)));
            break;
          case 'r':
          case 'R':
             e.preventDefault();
             resetControls();
             return prev; // resetControls sets state, so we return prev to avoid double render
        }
        return newControls;
      });
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [resetControls]);


  return (
    <div className="flex flex-col h-screen bg-base-100 overflow-hidden">
      <Header onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)} />
      <div className="flex flex-1 overflow-hidden">
        <main className="flex-1 p-4 md:p-8 flex flex-col items-center justify-center transition-all duration-300">
          <div className="w-full h-full grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-8">
            {imageData ? (
              <ImagePanel
                title="الصورة الأصلية"
                imageUrl={imageData.base64}
                imageInfo={imageInfo}
                histogramData={histogramData}
                onClear={handleClearImage}
              />
            ) : (
              <UploadPlaceholder onImageUpload={handleImageUpload} />
            )}
            
            <div className="bg-base-200 rounded-lg flex items-center justify-center relative overflow-hidden shadow-inner">
              {isLoading && (
                <div className="absolute inset-0 bg-black bg-opacity-50 flex flex-col items-center justify-center z-10">
                  <LoadingSpinner className="w-12 h-12 text-brand-primary" />
                  <p className="mt-4 text-lg">جاري المعالجة...</p>
                </div>
              )}
              {generatedImage ? (
                 <ImagePanel
                  title="الصورة الناتجة"
                  imageUrl={generatedImage.url}
                  imageInfo={generatedImage.info}
                />
              ) : (
                !isLoading && <div className="text-center text-base-content-secondary">
                  <p>ستظهر الصورة المُنشأة هنا</p>
                </div>
              )}
            </div>
          </div>
        </main>
        <Sidebar
          isOpen={isSidebarOpen}
          controls={controls}
          setControls={setControls}
          onGenerate={handleGenerate}
          onReset={resetControls}
          isLoading={isLoading}
          onImageUpload={handleImageUpload}
          hasImage={!!imageData}
          selectedTemplate={selectedTemplate}
          setSelectedTemplate={setSelectedTemplate}
        />
      </div>
    </div>
  );
};

export default App;

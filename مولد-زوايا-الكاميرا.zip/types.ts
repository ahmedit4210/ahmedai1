
export interface CameraControls {
  zoom: number;
  yaw: number;
  pitch: number;
  roll: number;
  panX: number;
  panY: number;
}

export interface ImageInfo {
  width: number;
  height: number;
  aspectRatio: string;
}

export interface HistogramData {
  r: number[];
  g: number[];
  b: number[];
}

export interface ImageData {
  file: File;
  base64: string;
  mimeType: string;
}

export interface PromptTemplate {
  id: string;
  name: string;
  template: string;
}

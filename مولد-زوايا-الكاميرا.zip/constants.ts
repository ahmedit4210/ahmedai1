
import type { CameraControls, PromptTemplate } from './types';

export const DEFAULT_CONTROLS: CameraControls = {
  zoom: 1,
  yaw: 0,
  pitch: 0,
  roll: 0,
  panX: 0,
  panY: 0,
};

export const PROMPT_TEMPLATES: PromptTemplate[] = [
  {
    id: 'generic',
    name: 'قالب عام',
    template: "Generate a photorealistic version of the provided reference image with the following camera transforms — Zoom: {zoom}x, Yaw: {yaw} degrees, Pitch: {pitch} degrees, Roll: {roll} degrees, PanX: {panx}, PanY: {pany}. Preserve the main subject, maintain realistic lighting and perspective, avoid adding or removing major objects, keep style and colors consistent. Output a single high-resolution image matching the input aspect ratio."
  },
  {
    id: 'close_up',
    name: 'لقطة قريبة',
    template: "From the reference image, create a close-up portrait (zoom {zoom}) focusing on the main subject. Induce a shallow depth-of-field effect to reduce background visibility. Keep natural lighting. Camera yaw {yaw}, pitch {pitch}."
  },
  {
    id: 'birds_eye',
    name: 'عين الطائر',
    template: "Using the reference image, generate a top-down Bird's Eye view (pitch {pitch}) while preserving the subject's shape. Adjust proportions realistically to fit the new perspective."
  },
    {
    id: 'dramatic_tilt',
    name: 'ميل درامي',
    template: "Recreate the scene from the reference image with a dramatic Dutch angle (roll: {roll} degrees). Enhance shadows and highlights for a cinematic feel. Keep camera settings at Zoom: {zoom}x, Yaw: {yaw}, Pitch: {pitch}."
  }
];

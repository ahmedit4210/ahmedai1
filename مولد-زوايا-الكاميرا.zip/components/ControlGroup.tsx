
import React, { useState } from 'react';
import { ChevronDownIcon } from './icons';

interface ControlGroupProps {
  title: string;
  children: React.ReactNode;
  defaultOpen?: boolean;
}

export const ControlGroup: React.FC<ControlGroupProps> = ({ title, children, defaultOpen = false }) => {
  const [isOpen, setIsOpen] = useState(defaultOpen);

  return (
    <div className="bg-base-100 rounded-lg">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center p-3 text-right font-bold"
      >
        <span>{title}</span>
        <ChevronDownIcon className={`w-5 h-5 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="p-3 border-t border-base-300 flex flex-col gap-3">
          {children}
        </div>
      )}
    </div>
  );
};

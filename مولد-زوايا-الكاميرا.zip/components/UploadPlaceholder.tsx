
import React, { useState, useCallback } from 'react';
import { UploadIcon } from './icons';

interface UploadPlaceholderProps {
    onImageUpload: (file: File) => void;
}

export const UploadPlaceholder: React.FC<UploadPlaceholderProps> = ({ onImageUpload }) => {
    const [isDragging, setIsDragging] = useState(false);

    const handleDragEnter = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(true);
    }, []);

    const handleDragLeave = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
    }, []);

    const handleDragOver = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
    }, []);

    const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
        e.preventDefault();
        e.stopPropagation();
        setIsDragging(false);
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
            onImageUpload(e.dataTransfer.files[0]);
        }
    }, [onImageUpload]);

    return (
        <div 
            onDragEnter={handleDragEnter}
            onDragLeave={handleDragLeave}
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            className={`bg-base-200 rounded-lg flex items-center justify-center border-2 border-dashed  transition-colors duration-300 ${isDragging ? 'border-brand-primary bg-base-300' : 'border-base-300'}`}
        >
            <label htmlFor="file-upload" className="flex flex-col items-center justify-center text-center text-base-content-secondary p-8 cursor-pointer">
                <UploadIcon className="w-12 h-12 mb-4"/>
                <h3 className="text-lg font-bold text-base-content">اسحب وأفلت صورة هنا</h3>
                <p className="mt-1">أو انقر للاختيار من جهازك</p>
                <p className="text-xs mt-2">(PNG, JPG, WEBP)</p>
            </label>
            <input id="file-upload" type="file" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={(e) => e.target.files && onImageUpload(e.target.files[0])}/>
        </div>
    );
}


import React from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import type { HistogramData } from '../types';

interface HistogramProps {
  data: HistogramData;
}

export const Histogram: React.FC<HistogramProps> = ({ data }) => {
  const chartData = data.r.map((_, i) => ({
    name: i,
    r: data.r[i],
    g: data.g[i],
    b: data.b[i],
  }));

  return (
    <div style={{ width: '100%', height: 100 }}>
        <ResponsiveContainer>
            <BarChart data={chartData} margin={{ top: 5, right: 5, left: -35, bottom: -10 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                <XAxis dataKey="name" tick={false} />
                <YAxis tick={{ fill: '#9CA3AF', fontSize: 10 }} />
                <Tooltip
                    contentStyle={{ backgroundColor: '#1F2937', border: '1px solid #4B5563', borderRadius: '0.5rem' }}
                    labelStyle={{ color: '#F9FAFB' }}
                    itemStyle={{ fontSize: 12 }}
                />
                <Bar dataKey="r" fill="#ef4444" barSize={10} />
                <Bar dataKey="g" fill="#22c55e" barSize={10} />
                <Bar dataKey="b" fill="#3b82f6" barSize={10} />
            </BarChart>
        </ResponsiveContainer>
    </div>
  );
};

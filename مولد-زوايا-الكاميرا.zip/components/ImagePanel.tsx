
import React, { useState } from 'react';
import { ImageInfo, HistogramData } from '../types';
import { Histogram } from './Histogram';
import { AnalyticsIcon, CloseIcon } from './icons';

interface ImagePanelProps {
  title: string;
  imageUrl: string;
  imageInfo: ImageInfo | null;
  histogramData?: HistogramData | null;
  onClear?: () => void;
}

export const ImagePanel: React.FC<ImagePanelProps> = ({ title, imageUrl, imageInfo, histogramData, onClear }) => {
  const [showAnalysis, setShowAnalysis] = useState(false);

  return (
    <div className="bg-base-200 rounded-lg flex flex-col h-full w-full relative overflow-hidden shadow-inner">
      <div className="p-3 bg-base-300 bg-opacity-50 flex items-center justify-between text-sm">
        <h3 className="font-bold">{title}</h3>
        <div className="flex items-center gap-2 text-base-content-secondary">
          {imageInfo && <span>{imageInfo.width}x{imageInfo.height} ({imageInfo.aspectRatio})</span>}
          {histogramData && (
             <button onClick={() => setShowAnalysis(!showAnalysis)} className={`p-1 rounded ${showAnalysis ? 'bg-brand-primary text-white' : 'hover:bg-base-100'}`}>
              <AnalyticsIcon className="w-4 h-4" />
            </button>
          )}
          {onClear && (
             <button onClick={onClear} className="p-1 rounded hover:bg-red-500 hover:text-white">
              <CloseIcon className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>
      <div className="flex-1 flex items-center justify-center p-2 min-h-0">
        <img src={imageUrl} alt={title} className="max-w-full max-h-full object-contain" />
      </div>
      {showAnalysis && histogramData && (
        <div className="bg-base-300 bg-opacity-80 p-2 backdrop-blur-sm">
          <h4 className="text-xs font-bold mb-1 text-center">تحليل الألوان</h4>
          <Histogram data={histogramData} />
        </div>
      )}
    </div>
  );
};


import React from 'react';
import { CameraControls } from '../types';
import { ControlGroup } from './ControlGroup';
import { SliderInput } from './SliderInput';
import { GenerateIcon, ResetIcon, UploadIcon, DownloadIcon } from './icons';
import { PROMPT_TEMPLATES } from '../constants';

interface SidebarProps {
  isOpen: boolean;
  controls: CameraControls;
  setControls: React.Dispatch<React.SetStateAction<CameraControls>>;
  onGenerate: () => void;
  onReset: () => void;
  isLoading: boolean;
  onImageUpload: (file: File) => void;
  hasImage: boolean;
  selectedTemplate: string;
  setSelectedTemplate: (id: string) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  controls,
  setControls,
  onGenerate,
  onReset,
  isLoading,
  onImageUpload,
  hasImage,
  selectedTemplate,
  setSelectedTemplate,
}) => {
  const handleControlChange = (key: keyof CameraControls, value: number) => {
    setControls(prev => ({ ...prev, [key]: value }));
  };
  
  const handlePreset = (preset: Partial<CameraControls>) => {
    setControls(prev => ({...prev, ...preset}));
  }

  return (
    <aside className={`bg-base-200 flex flex-col transition-all duration-300 overflow-hidden ${isOpen ? 'w-80 md:w-96' : 'w-0'}`}>
      <div className="p-4 flex-1 overflow-y-auto">
        <div className="flex flex-col gap-4">
          
          <label className="w-full text-center px-4 py-3 bg-brand-secondary hover:bg-opacity-90 text-white rounded-lg cursor-pointer flex items-center justify-center gap-2">
              <UploadIcon className="w-5 h-5" />
              <span>{hasImage ? 'تغيير الصورة' : 'رفع صورة'}</span>
              <input type="file" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={(e) => e.target.files && onImageUpload(e.target.files[0])} />
          </label>
          
          <ControlGroup title="قالب الأوامر" defaultOpen>
            <select
                value={selectedTemplate}
                onChange={(e) => setSelectedTemplate(e.target.value)}
                className="w-full p-2 bg-base-300 rounded-md border border-base-100 focus:ring-2 focus:ring-brand-primary focus:outline-none"
            >
                {PROMPT_TEMPLATES.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
            </select>
          </ControlGroup>

          <ControlGroup title="زوايا القرب">
            <div className="grid grid-cols-3 gap-2">
                <button onClick={() => handlePreset({ zoom: 2.5 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">قريب جداً</button>
                <button onClick={() => handlePreset({ zoom: 1 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">متوسط</button>
                <button onClick={() => handlePreset({ zoom: 0.5 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">بعيد</button>
            </div>
            <SliderInput label="تكبير/تصغير (Zoom)" min={0.25} max={4} step={0.01} value={controls.zoom} onChange={v => handleControlChange('zoom', v)} />
          </ControlGroup>
          
          <ControlGroup title="زوايا الاتجاه">
             <div className="grid grid-cols-4 gap-2">
                <button onClick={() => handlePreset({ yaw: 0 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">أمامي</button>
                <button onClick={() => handlePreset({ yaw: 180 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">خلفي</button>
                <button onClick={() => handlePreset({ yaw: -90 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">يسار</button>
                <button onClick={() => handlePreset({ yaw: 90 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">يمين</button>
            </div>
            <SliderInput label="الانحراف (Yaw)" min={-180} max={180} step={1} value={controls.yaw} onChange={v => handleControlChange('yaw', v)} />
          </ControlGroup>
          
          <ControlGroup title="زوايا الارتفاع">
            <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handlePreset({ pitch: 45 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">من الأسفل</button>
                <button onClick={() => handlePreset({ pitch: -45 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">من الأعلى</button>
            </div>
            <SliderInput label="الميل العمودي (Pitch)" min={-89} max={89} step={1} value={controls.pitch} onChange={v => handleControlChange('pitch', v)} />
          </ControlGroup>
          
          <ControlGroup title="تأثيرات خاصة">
             <div className="grid grid-cols-2 gap-2">
                <button onClick={() => handlePreset({ roll: 25 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">ميل درامي</button>
                <button onClick={() => handlePreset({ pitch: -89 })} className="text-sm py-1 px-2 bg-base-300 rounded hover:bg-brand-primary">عين الطائر</button>
            </div>
            <SliderInput label="الدوران (Roll)" min={-180} max={180} step={1} value={controls.roll} onChange={v => handleControlChange('roll', v)} />
          </ControlGroup>

          <ControlGroup title="تحريك الكاميرا (Pan)">
            <SliderInput label="أفقي (Pan X)" min={-1} max={1} step={0.01} value={controls.panX} onChange={v => handleControlChange('panX', v)} />
            <SliderInput label="عمودي (Pan Y)" min={-1} max={1} step={0.01} value={controls.panY} onChange={v => handleControlChange('panY', v)} />
          </ControlGroup>
          
        </div>
      </div>
      <div className="p-4 border-t border-base-300 flex flex-col gap-2">
         <button
          onClick={onGenerate}
          disabled={isLoading || !hasImage}
          className="w-full flex items-center justify-center gap-2 bg-brand-primary text-white font-bold py-3 px-4 rounded-lg hover:bg-opacity-90 transition-colors disabled:bg-base-300 disabled:cursor-not-allowed"
        >
          <GenerateIcon className="w-5 h-5" />
          {isLoading ? 'جاري التوليد...' : 'توليد'}
        </button>
        <button
          onClick={onReset}
          disabled={isLoading}
          className="w-full flex items-center justify-center gap-2 bg-base-300 text-base-content font-bold py-2 px-4 rounded-lg hover:bg-opacity-80 transition-colors disabled:opacity-50"
        >
          <ResetIcon className="w-5 h-5" />
          إعادة تعيين
        </button>
      </div>
    </aside>
  );
};

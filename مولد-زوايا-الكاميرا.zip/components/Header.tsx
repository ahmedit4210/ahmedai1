
import React from 'react';
import { MenuIcon, ShareIcon } from './icons';
import toast from 'react-hot-toast';

interface HeaderProps {
  onToggleSidebar: () => void;
}

export const Header: React.FC<HeaderProps> = ({ onToggleSidebar }) => {

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('تم نسخ الرابط!');
  };

  return (
    <header className="bg-base-200 shadow-md p-4 flex items-center justify-between z-20 flex-shrink-0">
      <div className="flex items-center gap-4">
         <button onClick={onToggleSidebar} className="p-2 rounded-md hover:bg-base-300 transition-colors">
          <MenuIcon className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-bold">مولد زوايا الكاميرا</h1>
      </div>
      <div className="flex items-center gap-2">
         <button onClick={handleShare} className="flex items-center gap-2 px-4 py-2 rounded-md bg-base-300 hover:bg-opacity-80 transition-colors text-sm">
          <ShareIcon className="w-4 h-4" />
          مشاركة
        </button>
      </div>
    </header>
  );
};

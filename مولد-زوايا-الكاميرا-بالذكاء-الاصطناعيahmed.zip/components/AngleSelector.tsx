
import React from 'react';
import { ANGLE_CATEGORIES } from '../constants';
import type { Angle } from '../types';

interface AngleSelectorProps {
  onAngleSelect: (angle: Angle) => void;
  isDisabled: boolean;
}

export const AngleSelector: React.FC<AngleSelectorProps> = ({ onAngleSelect, isDisabled }) => {
  return (
    <div className={`bg-gray-800 p-6 rounded-lg shadow-md border border-gray-700 transition-opacity duration-300 ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'opacity-100'}`}>
      <h2 className="text-xl font-semibold mb-4 text-white">2. اختر زاوية</h2>
      <div className="space-y-3">
        {ANGLE_CATEGORIES.map((category, index) => (
          <details key={category.title} className="bg-gray-700/50 rounded-lg group" open={index === 0}>
            <summary className="p-3 font-medium cursor-pointer list-none flex justify-between items-center text-cyan-400 group-hover:bg-gray-700/80 rounded-t-lg">
              {category.title}
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 transition-transform duration-300 group-open:rotate-180" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </summary>
            <div className="p-4 border-t border-gray-600">
              <ul className="space-y-2">
                {category.angles.map((angle) => (
                  <li key={angle.name}>
                    <button
                      onClick={() => onAngleSelect(angle)}
                      disabled={isDisabled}
                      className="w-full text-right bg-gray-600/50 p-2 rounded-md hover:bg-cyan-600 hover:text-white transition-colors duration-200 disabled:bg-gray-500 disabled:cursor-not-allowed"
                    >
                      {angle.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </details>
        ))}
      </div>
    </div>
  );
};

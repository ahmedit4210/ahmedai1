
import React from 'react';

export const Header: React.FC = () => (
  <header className="bg-gray-800 shadow-lg p-4 text-center">
    <h1 className="text-3xl md:text-4xl font-bold text-cyan-400">مولد زوايا الكاميرا</h1>
    <p className="text-gray-400 mt-1">أنشئ صورًا فريدة باستخدام الذكاء الاصطناعي</p>
  </header>
);

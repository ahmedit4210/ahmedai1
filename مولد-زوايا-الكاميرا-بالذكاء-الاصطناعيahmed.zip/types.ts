
export interface Angle {
  name: string;
  prompt: string;
}

export interface AngleCategory {
  title: string;
  angles: Angle[];
}


import React, { useState, useCallback, useEffect } from 'react';
import { Header } from './components/Header';
import { ImageUploader } from './components/ImageUploader';
import { AngleSelector } from './components/AngleSelector';
import { ImageViewer } from './components/ImageViewer';
import { ErrorMessage } from './components/ErrorMessage';
import { generateImageFromAngle } from './services/geminiService';
import type { Angle } from './types';

const App: React.FC = () => {
  const [originalImage, setOriginalImage] = useState<File | null>(null);
  const [originalImageUrl, setOriginalImageUrl] = useState<string | null>(null);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!originalImage) {
      setOriginalImageUrl(null);
      return;
    }

    const objectUrl = URL.createObjectURL(originalImage);
    setOriginalImageUrl(objectUrl);

    // Clean up the object URL when the component unmounts or the image changes
    return () => URL.revokeObjectURL(objectUrl);
  }, [originalImage]);

  const handleImageUpload = (file: File) => {
    setOriginalImage(file);
    setGeneratedImageUrl(null);
    setError(null);
  };

  const handleAngleSelect = useCallback(async (angle: Angle) => {
    if (!originalImage) {
      setError("الرجاء تحميل صورة أولاً.");
      return;
    }

    setIsLoading(true);
    setGeneratedImageUrl(null);
    setError(null);

    try {
      const imageUrl = await generateImageFromAngle(originalImage, angle.prompt);
      setGeneratedImageUrl(imageUrl);
    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء إنشاء الصورة. الرجاء المحاولة مرة أخرى.");
    } finally {
      setIsLoading(false);
    }
  }, [originalImage]);

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Header />
      <main className="container mx-auto p-4 md:p-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <aside className="lg:col-span-1 space-y-6">
            <ImageUploader onImageUpload={handleImageUpload} />
            <AngleSelector onAngleSelect={handleAngleSelect} isDisabled={!originalImage || isLoading} />
          </aside>
          
          <div className="lg:col-span-2">
            <ErrorMessage message={error} />
            <ImageViewer
              originalImageUrl={originalImageUrl}
              generatedImageUrl={generatedImageUrl}
              isLoading={isLoading}
            />
          </div>
        </div>
      </main>
      <footer className="text-center p-4 text-gray-500 text-sm">
        <p>مدعوم بواسطة Gemini 2.5 Flash</p>
      </footer>
    </div>
  );
};

export default App;
